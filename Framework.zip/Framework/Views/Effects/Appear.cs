using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;

namespace Sunfish.Views.Effects
{
	public class Appear : Effect
	{

		public Appear (double lengthInMilliseconds):
		base(lengthInMilliseconds)
		{
		}

		public Appear (double lengthInMilliseconds, SoundEffect sound):
			base(lengthInMilliseconds, sound)
		{
		}

		protected override void UpdateEffect (GameTime gameTime, View view)
		{
			// New code: avoids creating a new color every update
			float amountComplete = GetAmountComplete ();
			view.OverlayColor.R = (byte) (Byte.MaxValue * amountComplete);
			view.OverlayColor.G = (byte) (Byte.MaxValue * amountComplete);
			view.OverlayColor.B = (byte) (Byte.MaxValue * amountComplete);
			view.OverlayColor.A = (byte) (Byte.MaxValue * amountComplete);

			// Old code: created a new color every update
			//view.OverlayColor = new Color (new Vector4 (GetAmountComplete ()));

			view.Visible = true;
		}
	}
}

