using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;

namespace Sunfish.Views.Effects
{
	public class Rotate : Effect
	{

		private float InitialRadians { get; set; }

		private float FinalRadians { get; set; }

		private float DeltaRadians { get; set; }

		public Rotate (float initialRadians, float finalRadians, double lengthInMilliseconds, SoundEffect sound):
			base(lengthInMilliseconds, sound)
		{
			InitialRadians = initialRadians;
			FinalRadians = finalRadians;
			DeltaRadians = FinalRadians - initialRadians;
		}

		public Rotate (float initialRadians, float finalRadians, double lengthInMilliseconds):
			base(lengthInMilliseconds)
		{
			InitialRadians = initialRadians;
			FinalRadians = finalRadians;
			DeltaRadians = FinalRadians - initialRadians;
		}

		protected override void UpdateEffect (GameTime gameTime, View view)
		{
			float amountComplete;
			if (IsComplete (out amountComplete)) {
				view.RotationRadians = FinalRadians;
			} else {
				float offsetRadians = DeltaRadians * amountComplete;
				view.RotationRadians = InitialRadians + offsetRadians;
			}
		}
	}
}

